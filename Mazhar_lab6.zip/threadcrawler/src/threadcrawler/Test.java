package threadcrawler;
import org.junit.Test;
import java.io.File;


import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
public class Test {

	

	
	
	@Test
	public void search() 
	{
		String wordToSearch = "#include";
		
		Crawler crawler = new Crawler();
		crawler.StartTest();
		if(Crawler.map.getLength() < 1)
			fail(" File not Found");
		
		if(crawler.search(wordToSearch) < 1)
			fail("No Item Found");
	}
	
	@Test
	
	public void pathExists() 
	{
		File file = new File(Crawler.PATH);
		if(!file.exists())
			fail("Change Path to valid directory");
	}

}

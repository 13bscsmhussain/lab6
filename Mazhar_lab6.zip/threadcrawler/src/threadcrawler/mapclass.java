package threadcrawler;
import java.util.ArrayList;

public class mapclass {

	private ArrayList<String> key;
	private ArrayList<String> value;
	
	
	public mapclass()
	{
		key = new ArrayList<String>();
		value = new ArrayList<String>();
	}
	
	public void put(String key,String value)
	{
		this.key.add(key);
		this.value.add(value);
	}
	
	public int getLength()
	{
		return key.size();
	}
	
	public String getKeyAt(int index)
	{
		return key.get(index);
	}
	public String getValueAt(int index)
	{
		return value.get(index);
	}
	
	
	
}


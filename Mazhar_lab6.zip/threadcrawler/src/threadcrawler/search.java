package threadcrawler;
import java.util.Scanner;


public class search implements Runnable {

	private Scanner in;
	
	@Override
	public void run() {

		display("Enter a String to search");
		
		Boolean continuesearch = true;
		in = new Scanner(System.in);
		
		while(continuesearch)
		{
			display("Enter Text to search..");
			String text = in.nextLine();
			if(text=="NULL")
				continuesearch = false;
			else
			{
				search(text);
				display("******");
			}
		}
	}
	
	
	
	

	private void display(String display)
	{
		System.out.println(display);
	}
	

	public void search(String text) {
		Boolean found = false;
		mapclass map = Crawler.map;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				display(text + " In file: " + map.getValueAt(i)); 
				found = true;
			}
			
		}
		
		if(!found)
			display("No File Found");
	}
}

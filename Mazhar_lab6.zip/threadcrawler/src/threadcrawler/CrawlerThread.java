package threadcrawler;
import java.io.File;


public class CrawlerThread extends Thread {

	public static int threadCount;
	private String PATH;
	
	
	public CrawlerThread(String path)
	{
		this.PATH = path;
	}
	

	public void run()
	{
		threadCount++;
		
		craweler(new File(PATH));
		threadCount--;
	}
	
	public void craweler(File root)
	{
		File[] file = root.listFiles();
		for(int i = 0; i < file.length ; i++)
		    if(file[i].isDirectory())
		    {
		    	if(threadCount < 5)
		    	{
		    		CrawlerThread thread = new CrawlerThread(file[i].getAbsolutePath());
		    		thread.run();
		    	}
		    	else
		    	{
		    		craweler(file[i]);
		    	}
		    }
		    else
		    {
		    	if(file[i].getName().contains(".txt")){
		    		Crawler.filesTobeIndexed.add(file[i]);
		    	}
		    }
	}
}

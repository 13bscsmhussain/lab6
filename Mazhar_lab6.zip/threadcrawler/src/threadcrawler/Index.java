package threadcrawler;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Index implements Runnable {

	
	public void run()
	{
		while(true)
		{
			if(Crawler.filesTobeIndexed.size() == 0)
			{
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
				}
			}
			else
			{
				ArrayList<File> filesTobeIndexed = new ArrayList<File>();
				for(int i = 0; i < 
				Crawler.filesTobeIndexed.size(); i++)
				{
					filesTobeIndexed.add(Crawler.filesTobeIndexed.get(i));
				}
				Crawler.filesTobeIndexed.clear();
				
				for(int i = 0; i < filesTobeIndexed.size(); i++)
				{
					index(filesTobeIndexed.get(i));
				}
				
			}
		}
	}
	
	private synchronized void index(File file) 
	{
		try
		{
			List<String> lines = Files.readAllLines(Paths.get(file.getAbsolutePath()),StandardCharsets.UTF_8);
			for(String line: lines)
			{
				String[] words = line.split(" ");
				for(String s: words)
				{
					Crawler.map.put(s, file.getAbsolutePath());
				}
			}
		}
		catch(IOException e)
		{
			System.out.println(file.getAbsolutePath());
			e.printStackTrace();
		}
	}
}


package threadcrawler;
import java.io.File;
import java.util.ArrayList;


public class Crawler 
{
	public static final String PATH = "D:\\";
	static mapclass map;
	static ArrayList<File> filesTobeIndexed;
	

	
	public Crawler()
	{
		 map = new mapclass();
		 filesTobeIndexed = new ArrayList<File>();
	}
	
	
	public static void main(String [] args)
	{
		Crawler crawler = new Crawler();
		crawler.start();
	}

	public void start() 
	{
		display("Searching");
		
		Thread thread = new CrawlerThread(PATH);
		thread.setDaemon(true);
		thread.start();

		Thread indexerThread = new Thread(new Index());
		indexerThread.setDaemon(true);
		indexerThread.start();
	
		Thread searching = new Thread(new search());
		searching.start();
		
		try {
			thread.join();
			searching.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			
		display("Leaving");
	}
	
	
	public void StartTest()
	{
		display("Searching");
		
		Thread thread = new CrawlerThread(PATH);	
		thread.setDaemon(true);						
		thread.start();								

		Thread indexerThread = new Thread(new Index());		
		indexerThread.setDaemon(true);							
		indexerThread.start();									

		try {
			thread.join();								
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public int search(String text) {
		Boolean found = false;
		int results = 0;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				display(text + " In file: " + map.getValueAt(i)); 
				found = true;
				results++;
				}
		}
		
		if(!found)
			display("No Results Found");
		
		return results;
	}

	private void display(String display)
	{
		System.out.println(display);
	}
	
	
}

